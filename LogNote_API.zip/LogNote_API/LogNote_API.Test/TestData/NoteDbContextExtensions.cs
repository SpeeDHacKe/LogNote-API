﻿using LogNote_API.DataAccess.Interfaces;
using LogNote_API.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace LogNote_API.Test.TestData
{
    public static class NoteDbContextExtensions
    {
        public static void LoadData(this INoteDbContext context)
        {
            context.Note.InsertMany(new List<NoteModel>()
            {
                new NoteModel
                {
                    csnNo = "00000002",
                    contractNo = "c1000001",
                    noteDate = Convert.ToDateTime("2018-08-20T15:00:00"),
                    noteTime = Convert.ToDateTime("2019-12-12T18:18:18"),
                    actionCode = "CF1",
                    personCode = "PC000001",
                    resultCode = "CR01",
                    noteDescription = "ระวังการติดต่อหรือสามารถติดต่อ (Type no,เบอร์โทร,เวลา) ตามที่แจ้ง",
                    ppDate = Convert.ToDateTime("2019-08-20T15:00:00"),
                    ppTime = Convert.ToDateTime("2021-08-20T15:00:00"),
                    pdDate = Convert.ToDateTime("2020-08-20T15:00:00"),
                    pdTime = Convert.ToDateTime("2021-08-20T15:00:00"),
                    recallDate = Convert.ToDateTime("2021-05-20T15:00:00"),
                    recallTime = Convert.ToDateTime("2021-09-20T15:00:00"),
                    ppAmt = Convert.ToDecimal(500.5231),
                    alreadyPaidAmt = Convert.ToDecimal(55555.2536889),
                    ppChannel = "PP0292",
                    callCenter = "CC-CS04",
                    telType = "TT05",
                    telNo = "+66861234567",
                    callType = "CT8595",
                    contactTo = "คำอธิบาย",
                    systemBy = "CSSCREEN",
                    flagDelete = "1",
                    recordStatus = "1",
                    createDate = Convert.ToDateTime("2017-04-20T11:00:00"),
                    createBy = "IT USER",
                    updateDate = Convert.ToDateTime("2021-09-20T15:00:00"),
                    updateBy = "IT USER"
                },
                new NoteModel
                {
                    csnNo = "00000006",
                    contractNo = "c1000005",
                    noteDate = Convert.ToDateTime("2021-08-20T15:00:00"),
                    noteTime = Convert.ToDateTime("2020-08-20T15:00:00"),
                    actionCode = "CF9",
                    personCode = "PC000005",
                    resultCode = "CR02",
                    noteDescription = "ระวังการติดต่อหรือสามารถติดต่อ (Type no,เบอร์โทร,เวลา) ตามที่แจ้ง",
                    ppDate = Convert.ToDateTime("2019-08-20T15:00:00"),
                    ppTime = Convert.ToDateTime("2021-08-20T15:00:00"),
                    pdDate = Convert.ToDateTime("2020-08-20T15:00:00"),
                    pdTime = Convert.ToDateTime("2021-08-20T15:00:00"),
                    recallDate = Convert.ToDateTime("2021-05-20T15:00:00"),
                    recallTime = Convert.ToDateTime("2021-09-20T15:00:00"),
                    ppAmt = Convert.ToDecimal(500.5231),
                    alreadyPaidAmt = Convert.ToDecimal(55555.2536889),
                    ppChannel = "PP0296",
                    callCenter = "CC-CS09",
                    telType = "TT09",
                    telNo = "+66896312345",
                    callType = "CT8595",
                    contactTo = "คำอธิบาย",
                    systemBy = "CSSCREEN",
                    flagDelete = "1",
                    recordStatus = "1",
                    createDate = Convert.ToDateTime("2021-09-20T15:00:00"),
                    createBy = "IT USER",
                    updateDate = Convert.ToDateTime("2021-09-20T15:00:00"),
                    updateBy = "IT USER"
                },
                new NoteModel
                {
                    csnNo = "00000007",
                    contractNo = "c1000006",
                    noteDate = Convert.ToDateTime("2021-08-20T15:00:00"),
                    noteTime = Convert.ToDateTime("2020-08-20T15:00:00"),
                    actionCode = "CF9A",
                    personCode = "PC000025",
                    resultCode = "CR20",
                    noteDescription = "ระวังการติดต่อหรือสามารถติดต่อ (Type no,เบอร์โทร,เวลา) ตามที่แจ้ง",
                    ppDate = Convert.ToDateTime("2011-08-20T15:00:00"),
                    ppTime = Convert.ToDateTime("2012-08-20T15:00:00"),
                    pdDate = Convert.ToDateTime("2011-07-20T15:00:00"),
                    pdTime = Convert.ToDateTime("2012-07-20T15:00:00"),
                    recallDate = Convert.ToDateTime("2019-05-20T15:00:00"),
                    recallTime = Convert.ToDateTime("2019-09-20T15:00:00"),
                    ppAmt = Convert.ToDecimal(5001.5231),
                    alreadyPaidAmt = Convert.ToDecimal(10555.2536889),
                    ppChannel = "PP0290",
                    callCenter = "CC-CS04",
                    telType = "TT08",
                    telNo = "+66896312379",
                    callType = "CT8500",
                    contactTo = "คำอธิบาย",
                    systemBy = "CSSCREEN",
                    flagDelete = "0",
                    recordStatus = "1",
                    createDate = Convert.ToDateTime("2021-12-20T15:00:00"),
                    createBy = "IT USER",
                    updateDate = Convert.ToDateTime("2021-12-20T15:00:00"),
                    updateBy = "IT USER"
                }
            });
        }
    }
}
