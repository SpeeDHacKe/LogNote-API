using LogNote_API.DataAccess;
using LogNote_API.DataAccess.Interfaces;
using Mongo2Go;
using MongoDB.Driver;
using System;
using Xunit;

namespace LogNote_API.Test
{
    public class InitMongo
    {
        public MongoDbRunner _runner;
        public INoteDbContext _context;
        private readonly IMongoClient _client;
        private readonly string _db = "Note_DB";

        public InitMongo()
        {
            _runner = MongoDbRunner.Start();
            _client = new MongoClient(_runner.ConnectionString);
            _context = new NoteDbContext(_client, _db);
        }
    }
}
