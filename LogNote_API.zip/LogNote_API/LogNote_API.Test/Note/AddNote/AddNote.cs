﻿using LogNote_API.Models;
using LogNote_API.Services;
using LogNote_API.Test.Note.GetNote.Theory;
using System;
using System.Collections.Generic;
using System.Text;
using Xunit;

namespace LogNote_API.Test.Note.AddNote
{
    public class AddNote : InitMongo
    {
        [Theory]
        [ClassData(typeof(Theory_TrueCase_AddNote))]
        public void AddNote_Success_Return_Result(List<NoteModel> note)
        {
            var service = new NoteService(_context);
            var result = service.AddNote(note);
            Assert.True(result.Exception == null);
            _runner.Dispose();
        }

        [Theory]
        [ClassData(typeof(Theory_FalseCase_AddNote))]
        public void AddNote_Failure_Return_Exception(List<NoteModel> note)
        {
            var service = new NoteService(_context);
            Assert.ThrowsAsync<Exception>(() => service.AddNote(note));
            _runner.Dispose();
        }
    }
}
