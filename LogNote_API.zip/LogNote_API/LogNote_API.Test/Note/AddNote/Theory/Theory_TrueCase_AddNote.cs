﻿using LogNote_API.Models;
using System;
using System.Collections.Generic;
using System.Text;
using Xunit;

namespace LogNote_API.Test.Note.GetNote.Theory
{
    public class Theory_TrueCase_AddNote : TheoryData<List<NoteModel>>
    {
        public Theory_TrueCase_AddNote()
        {

            Add(new List<NoteModel>()
            {
                new NoteModel
                {
                    csnNo = "00000012",
                    contractNo = "c1000001",
                    noteDate = Convert.ToDateTime("2018-08-20T15:00:00"),
                    noteTime = Convert.ToDateTime("2019-12-12T18:18:18"),
                    actionCode = "CF1",
                    personCode = "PC000001",
                    resultCode = "CR01",
                    noteDescription = "ระวังการติดต่อหรือสามารถติดต่อ (Type no,เบอร์โทร,เวลา) ตามที่แจ้ง",
                    ppDate = Convert.ToDateTime("2019-08-20T15:00:00"),
                    ppTime = Convert.ToDateTime("2021-08-20T15:00:00"),
                    pdDate = Convert.ToDateTime("2020-08-20T15:00:00"),
                    pdTime = Convert.ToDateTime("2021-08-20T15:00:00"),
                    recallDate = Convert.ToDateTime("2021-05-20T15:00:00"),
                    recallTime = Convert.ToDateTime("2021-09-20T15:00:00"),
                    ppAmt = Convert.ToDecimal(500.5231),
                    alreadyPaidAmt = Convert.ToDecimal(55555.2536889),
                    ppChannel = "PP0292",
                    callCenter = "CC-CS04",
                    telType = "TT05",
                    telNo = "+66861234567",
                    callType = "CT8595",
                    contactTo = "คำอธิบาย",
                    systemBy = "CSSCREEN",
                    flagDelete = "1",
                    recordStatus = "1",
                    createDate = Convert.ToDateTime("2017-04-20T11:00:00"),
                    createBy = "IT USER",
                    updateDate = Convert.ToDateTime("2021-09-20T15:00:00"),
                    updateBy = "IT USER"
                },
                new NoteModel
                {
                    csnNo = "00000013",
                    contractNo = "c1000002",
                    noteDate = Convert.ToDateTime("2018-08-20T15:00:00"),
                    noteTime = Convert.ToDateTime("2019-12-12T18:18:18"),
                    actionCode = "CF1",
                    personCode = "PC000001",
                    resultCode = "CR01",
                    noteDescription = "ระวังการติดต่อหรือสามารถติดต่อ (Type no,เบอร์โทร,เวลา) ตามที่แจ้ง",
                    ppDate = Convert.ToDateTime("2019-08-20T15:00:00"),
                    ppTime = Convert.ToDateTime("2021-08-20T15:00:00"),
                    pdDate = Convert.ToDateTime("2020-08-20T15:00:00"),
                    pdTime = Convert.ToDateTime("2021-08-20T15:00:00"),
                    recallDate = Convert.ToDateTime("2021-05-20T15:00:00"),
                    recallTime = Convert.ToDateTime("2021-09-20T15:00:00"),
                    ppAmt = Convert.ToDecimal(500.5231),
                    alreadyPaidAmt = Convert.ToDecimal(55555.2536889),
                    ppChannel = "PP0292",
                    callCenter = "CC-CS04",
                    telType = "TT05",
                    telNo = "+66861234567",
                    callType = "CT8595",
                    contactTo = "คำอธิบาย",
                    systemBy = "CSSCREEN",
                    flagDelete = "1",
                    recordStatus = "1",
                    createDate = Convert.ToDateTime("2017-04-20T11:00:00"),
                    createBy = "IT USER",
                    updateDate = Convert.ToDateTime("2021-09-20T15:00:00"),
                    updateBy = "IT USER"
                },
                new NoteModel
                {
                    csnNo = "00000014",
                    contractNo = "c1000003",
                    noteDate = Convert.ToDateTime("2018-08-20T15:00:00"),
                    noteTime = Convert.ToDateTime("2019-12-12T18:18:18"),
                    actionCode = "CF1",
                    personCode = "PC000001",
                    resultCode = "CR01",
                    noteDescription = "ระวังการติดต่อหรือสามารถติดต่อ (Type no,เบอร์โทร,เวลา) ตามที่แจ้ง",
                    ppDate = Convert.ToDateTime("2019-08-20T15:00:00"),
                    ppTime = Convert.ToDateTime("2021-08-20T15:00:00"),
                    pdDate = Convert.ToDateTime("2020-08-20T15:00:00"),
                    pdTime = Convert.ToDateTime("2021-08-20T15:00:00"),
                    recallDate = Convert.ToDateTime("2021-05-20T15:00:00"),
                    recallTime = Convert.ToDateTime("2021-09-20T15:00:00"),
                    ppAmt = Convert.ToDecimal(500.5231),
                    alreadyPaidAmt = Convert.ToDecimal(55555.2536889),
                    ppChannel = "PP0292",
                    callCenter = "CC-CS04",
                    telType = "TT05",
                    telNo = "+66861234567",
                    callType = "CT8595",
                    contactTo = "คำอธิบาย",
                    systemBy = "CSSCREEN",
                    flagDelete = "1",
                    recordStatus = "1",
                    createDate = Convert.ToDateTime("2017-04-20T11:00:00"),
                    createBy = "IT USER",
                    updateDate = Convert.ToDateTime("2021-09-20T15:00:00"),
                    updateBy = "IT USER"
                }
            });




            //List<NoteModel> note = new List<NoteModel>
            //{
            //    new NoteModel
            //    {
            //        csnNo = "00000013",
            //        contractNo = "c1000002",
            //        noteDate = Convert.ToDateTime("2018-08-20T15:00:00"),
            //        noteTime = Convert.ToDateTime("2019-12-12T18:18:18"),
            //        actionCode = "CF1",
            //        personCode = "PC000001",
            //        resultCode = "CR01",
            //        noteDescription = "ระวังการติดต่อหรือสามารถติดต่อ (Type no,เบอร์โทร,เวลา) ตามที่แจ้ง",
            //        ppDate = Convert.ToDateTime("2019-08-20T15:00:00"),
            //        ppTime = Convert.ToDateTime("2021-08-20T15:00:00"),
            //        pdDate = Convert.ToDateTime("2020-08-20T15:00:00"),
            //        pdTime = Convert.ToDateTime("2021-08-20T15:00:00"),
            //        recallDate = Convert.ToDateTime("2021-05-20T15:00:00"),
            //        recallTime = Convert.ToDateTime("2021-09-20T15:00:00"),
            //        ppAmt = Convert.ToDecimal(500.5231),
            //        alreadyPaidAmt = Convert.ToDecimal(55555.2536889),
            //        ppChannel = "PP0292",
            //        callCenter = "CC-CS04",
            //        telType = "TT05",
            //        telNo = "+66861234567",
            //        callType = "CT8595",
            //        contactTo = "คำอธิบาย",
            //        systemBy = "CSSCREEN",
            //        flagDelete = "1",
            //        recordStatus = "1",
            //        createDate = Convert.ToDateTime("2017-04-20T11:00:00"),
            //        createBy = "IT USER",
            //        updateDate = Convert.ToDateTime("2021-09-20T15:00:00"),
            //        updateBy = "IT USER"
            //    },
            //    new NoteModel
            //    {
            //        csnNo = "00000014",
            //        contractNo = "c1000003",
            //        noteDate = Convert.ToDateTime("2018-08-20T15:00:00"),
            //        noteTime = Convert.ToDateTime("2019-12-12T18:18:18"),
            //        actionCode = "CF1",
            //        personCode = "PC000001",
            //        resultCode = "CR01",
            //        noteDescription = "ระวังการติดต่อหรือสามารถติดต่อ (Type no,เบอร์โทร,เวลา) ตามที่แจ้ง",
            //        ppDate = Convert.ToDateTime("2019-08-20T15:00:00"),
            //        ppTime = Convert.ToDateTime("2021-08-20T15:00:00"),
            //        pdDate = Convert.ToDateTime("2020-08-20T15:00:00"),
            //        pdTime = Convert.ToDateTime("2021-08-20T15:00:00"),
            //        recallDate = Convert.ToDateTime("2021-05-20T15:00:00"),
            //        recallTime = Convert.ToDateTime("2021-09-20T15:00:00"),
            //        ppAmt = Convert.ToDecimal(500.5231),
            //        alreadyPaidAmt = Convert.ToDecimal(55555.2536889),
            //        ppChannel = "PP0292",
            //        callCenter = "CC-CS04",
            //        telType = "TT05",
            //        telNo = "+66861234567",
            //        callType = "CT8595",
            //        contactTo = "คำอธิบาย",
            //        systemBy = "CSSCREEN",
            //        flagDelete = "1",
            //        recordStatus = "1",
            //        createDate = Convert.ToDateTime("2017-04-20T11:00:00"),
            //        createBy = "IT USER",
            //        updateDate = Convert.ToDateTime("2021-09-20T15:00:00"),
            //        updateBy = "IT USER"
            //    }
            //};

        }
    }
}
