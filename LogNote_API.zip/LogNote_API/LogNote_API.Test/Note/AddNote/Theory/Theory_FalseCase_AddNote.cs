﻿using LogNote_API.Models;
using System;
using System.Collections.Generic;
using System.Text;
using Xunit;

namespace LogNote_API.Test.Note.GetNote.Theory
{
    public class Theory_FalseCase_AddNote : TheoryData<List<NoteModel>>
    {
        public Theory_FalseCase_AddNote()
        {
            Add(null);
        }
    }
}
