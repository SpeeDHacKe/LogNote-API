﻿using LogNote_API.Models;
using LogNote_API.Services;
using LogNote_API.Test.Note.GetNote.Theory;
using LogNote_API.Test.TestData;
using System;
using System.Collections.Generic;
using System.Text;
using Xunit;
using System.Linq;

namespace LogNote_API.Test.Note.GetNote
{
    public class GetNote : InitMongo
    {
        [Theory]
        [ClassData(typeof(Theory_TrueCase_GetNote))]
        public void GetNote_Success_Return_Data(ResourceInput reInput)
        {
            _context.LoadData();
            var service = new NoteService(_context);
            var data = service.GetLogNote(reInput).Result;
            Assert.True(data.IsEmpty() || !data.IsEmpty());
            _runner.Dispose();
        }

        [Theory]
        [ClassData(typeof(Theory_FalseCase_GetNote))]
        public void GetNote_Failure_Return_Exception(ResourceInput reInput)
        {
            _context.LoadData();
            var service = new NoteService(_context);
            Assert.ThrowsAsync<Exception>(() => service.GetLogNote(reInput));
            _runner.Dispose();
        }
    }
}
