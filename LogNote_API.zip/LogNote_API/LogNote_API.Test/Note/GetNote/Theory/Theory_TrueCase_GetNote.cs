﻿using LogNote_API.Models;
using System;
using System.Collections.Generic;
using System.Text;
using Xunit;

namespace LogNote_API.Test.Note.GetNote.Theory
{
    public class Theory_TrueCase_GetNote : TheoryData<ResourceInput>
    {
        public Theory_TrueCase_GetNote()
        {
            Add(new ResourceInput
            {
                columnName = "csnNo",
                searchValue = "00000006"
            });

            Add(new ResourceInput
            {
                columnName = "csnNo",
                searchValue = "00000010"
            });

            Add(new ResourceInput
            {
                columnName = "",
                searchValue = "00000010"
            });
        }
    }
}
