﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LogNote_API.Models
{
    public class NoteModel
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public String id { get; set; }
        public String csnNo { get; set; }
        public String contractNo { get; set; }
        public DateTime? noteDate { get; set; }
        public DateTime? noteTime { get; set; }
        public String actionCode { get; set; }
        public String personCode { get; set; }
        public String resultCode { get; set; }
        public String noteDescription { get; set; }
        public DateTime? ppDate { get; set; }
        public DateTime? ppTime { get; set; }
        public DateTime? pdDate { get; set; }
        public DateTime? pdTime { get; set; }
        public DateTime? recallDate { get; set; }
        public DateTime? recallTime { get; set; }
        public Decimal128 ppAmt { get; set; }
        public Decimal128 alreadyPaidAmt { get; set; }
        public String ppChannel { get; set; }
        public String callCenter { get; set; }
        public String telType { get; set; }
        public String telNo { get; set; }
        public String callType { get; set; }
        public String contactTo { get; set; }
        public String systemBy { get; set; }
        public String flagDelete { get; set; }
        public String recordStatus { get; set; }
        public DateTime? createDate { get; set; }
        public String createBy { get; set; }
        public DateTime? updateDate { get; set; }
        public String updateBy { get; set; }
    }

    public class ResourceInput
    {
        public string columnName { get; set; }
        public string searchValue { get; set; }
    }
}
