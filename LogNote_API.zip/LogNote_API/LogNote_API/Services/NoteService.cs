﻿using LogNote_API.DataAccess;
using LogNote_API.DataAccess.Interfaces;
using LogNote_API.Models;
using LogNote_API.Services.Interfaces;
using MongoDB.Bson;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;

namespace LogNote_API.Services
{
    public class NoteService : INoteService
    {

        private readonly INoteDbContext _context;
        public NoteService(INoteDbContext context)
        {
            _context = context;
        }
        

        public async Task<NoteModel> GetNoteByNote(string note)
        {
            try
            {
                return await _context.Note.Find(a => a.csnNo == note).FirstOrDefaultAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public async Task<List<NoteModel>> GetLogNote(ResourceInput reInput)
        {
            try
            {
                var model = new NoteModel();
                Type type = model.GetType();
                PropertyInfo[] props = type.GetProperties(BindingFlags.Instance | BindingFlags.Public);
                var _filter = Builders<NoteModel>.Filter;
                var _filters = new List<FilterDefinition<NoteModel>>();
                FilterDefinition<NoteModel> cmdSearch;

                if (string.IsNullOrEmpty(reInput.columnName) && !string.IsNullOrEmpty(reInput.searchValue))
                {
                    for (int i = 0; i < props.Length; i++)
                    {
                        _filters.Add(Builders<NoteModel>.Filter.Regex(props[i].Name, reInput.searchValue));
                    }
                    cmdSearch = _filter.Or(_filters);
                }
                else
                {
                    cmdSearch = _filter.Regex(reInput.columnName, reInput.searchValue);
                }

                return await _context.Note.Find(cmdSearch).ToListAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public async Task<List<NoteModel>> GetAllNote()
        {
            try
            {
                return await _context.Note.Find(_ => true).ToListAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public NoteModel GetJoinNote(string note)
        {
            try
            {

                var join = (from a in _context.Note.AsQueryable()
                            join b in _context.Note.AsQueryable() on a.csnNo equals b.csnNo
                            select new NoteModel()
                            {
                                csnNo = a.csnNo,
                                contractNo = b.contractNo,
                                actionCode = a.actionCode
                            });

                return join.FirstOrDefault();
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }


        public async Task SetNote(NoteModel model)
        {
            try
            {
                var data = await _context.Note.Find(a => a.csnNo == model.csnNo).FirstOrDefaultAsync();

                if (data != null)
                {
                    //data.id = model.id;
                    //data.csnNo = model.csnNo;
                    data.contractNo = model.contractNo;
                    data.noteDate = model.noteDate;
                    data.noteTime = model.noteTime;
                    data.actionCode = model.actionCode;
                    data.personCode = model.personCode;
                    data.resultCode = model.resultCode;
                    data.noteDescription = model.noteDescription;
                    data.ppDate = model.ppDate;
                    data.ppTime = model.ppTime;
                    data.pdDate = model.pdDate;
                    data.pdTime = model.pdTime;
                    data.recallDate = model.recallDate;
                    data.recallTime = model.recallTime;
                    data.ppAmt = model.ppAmt;
                    data.alreadyPaidAmt = model.alreadyPaidAmt;
                    data.ppChannel = model.ppChannel;
                    data.callCenter = model.callCenter;
                    data.telType = model.telType;
                    data.telNo = model.telNo;
                    data.callType = model.callType;
                    data.contactTo = model.contactTo;
                    data.systemBy = model.systemBy;
                    data.flagDelete = model.flagDelete;
                    data.recordStatus = model.recordStatus;
                    data.createDate = model.createDate;
                    data.createBy = model.createBy;
                    data.updateDate = model.updateDate;
                    data.updateBy = model.updateBy;

                    var result = await _context.Note.ReplaceOneAsync(f => f.csnNo == model.csnNo, data);

                    if (result.IsAcknowledged && result.ModifiedCount == 0)
                    {
                        throw new Exception($"Not found record for update brand {model.csnNo}.");
                    }
                }
                else
                {
                    throw new Exception($"Not found record for update brand {model.csnNo}.");
                }
             
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task AddNote(List<NoteModel> data)
        {
            //List<NoteModel> model2 = List<NoteModel>();
            //List<BsonDocument> model2 = new List<BsonDocument>();
            try
            {
                //BulkWriteResult<NoteModel> xx = await BulkWriteAsync(model);
                await _context.Note.InsertManyAsync(data);
                //await _context.Note.InsertOneAsync(model);
            } 
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task RemoveNote(string note)
        {
            try
            {
                var result = await _context.Note.DeleteOneAsync(f => f.csnNo == note);

                if (result.IsAcknowledged && result.DeletedCount == 0)
                {
                    throw new Exception($"Not found record for delete brand {note}.");
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
