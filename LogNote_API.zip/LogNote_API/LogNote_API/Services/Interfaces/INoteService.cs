﻿using LogNote_API.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LogNote_API.Services.Interfaces
{
    public interface INoteService
    {
        Task<NoteModel> GetNoteByNote(string note);
        Task<List<NoteModel>> GetLogNote(ResourceInput reInput);
        Task<List<NoteModel>> GetAllNote();
        NoteModel GetJoinNote(string note);
        Task SetNote(NoteModel model);
        Task AddNote(List<NoteModel> model);
        Task RemoveNote(string note);

    }
}
