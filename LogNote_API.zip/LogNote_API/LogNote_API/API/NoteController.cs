﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using LogNote_API.Models;
using LogNote_API.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.DependencyInjection;

namespace LogNote_API.API
{
    [Route("api/[controller]")]
    [ApiController]
    public class NoteController : ControllerBase
    {
        private readonly IServiceProvider _service;

        public NoteController(IServiceProvider service)
        {
            _service = service;
        }

        [HttpGet("{note}", Name = "GetNoteByNote")]
        public async Task<NoteModel> GetNoteByNote(string note)
        {
            var noteService = _service.GetService<INoteService>();
            return await noteService.GetNoteByNote(note);
        }

        [HttpPost("GetLogNote", Name = "GetLogNote")]
        public async Task<List<NoteModel>> GetLogNote([FromBody] ResourceInput reInput)
        {
            var noteService = _service.GetService<INoteService>();
            return await noteService.GetLogNote(reInput);
        }

        [HttpGet("All", Name = "GetAllNote")]
        public async Task<List<NoteModel>> GetAllNote()
        {
            var noteService = _service.GetService<INoteService>();
            return await noteService.GetAllNote();
        }

        [HttpGet("Join/{note}", Name = "GetJoinNote")]
        public NoteModel GetJoinNote(string note)
        {
            var noteService = _service.GetService<INoteService>();
            return noteService.GetJoinNote(note);
        }

        [HttpPut(Name = "UpdateNote")]
        public async Task UpdateNote([FromBody] NoteModel data)
        {
            var noteService = _service.GetService<INoteService>();
            await noteService.SetNote(data);
        }

        [HttpPost(Name = "InsertNote")]
        public async Task InsertNote([FromBody] List<NoteModel> data)
        {
            var noteService = _service.GetService<INoteService>();
            await noteService.AddNote(data);
        }

        [HttpDelete("{note}", Name = "DeleteNote")]
        public async Task DeleteNote(string note)
        {
            var noteService = _service.GetService<INoteService>();
            await noteService.RemoveNote(note);
        }
    }
}
