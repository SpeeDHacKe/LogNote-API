﻿using LogNote_API.Models;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LogNote_API.DataAccess.Interfaces
{
    public interface INoteDbContext
    {
        IMongoCollection<NoteModel> Note { get; }
    }
}
